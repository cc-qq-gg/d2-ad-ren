<template>
  <el-menu-item :index="menu.name || uniqueId">
    <d2-icon-svg :name="menu.icon"/>
    <span slot="title">{{menu.title}}</span>
  </el-menu-item>
</template>

<script>
import { uniqueId } from 'lodash'
export default {
  name: 'd2-layout-header-aside-menu-item',
  props: {
    menu: {
      type: Object,
      required: false,
      default: () => {}
    }
  },
  data () {
    return {
      uniqueId: uniqueId('d2-menu-empty-')
    }
  }
}
</script>
